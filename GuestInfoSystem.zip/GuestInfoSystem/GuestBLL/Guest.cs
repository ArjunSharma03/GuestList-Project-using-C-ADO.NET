﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;

namespace GuestBLL
{
    public class Guest
    {
        public int GuestId { get; set; }
        public string GuestName { get; set; }
        public string MobileNo { get; set; }
        public string GuestCity { get; set; }
    }
}
