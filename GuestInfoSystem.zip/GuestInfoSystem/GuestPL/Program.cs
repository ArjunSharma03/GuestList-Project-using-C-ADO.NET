﻿using System;
using GuestDal;
using GuestBLL;
using System.Data.SqlClient;

namespace GuestPL
{
    class Program
    {
        static void Main(string[] args)
        {
            int x = 0;
            do
            {
                Console.WriteLine("\n\n----------------------------------");
                Console.WriteLine("1: Insert Guest in Table");
                Console.WriteLine("2: Display All Guest from Table");
                Console.WriteLine("3: Display a particular Guest from Table");
                Console.WriteLine("4: Delete a Guest from Table");          
                Console.WriteLine("5: Exit Application");
                Console.WriteLine("----------------------------------\n\n");
                int a = Convert.ToInt32(Console.ReadLine());

                switch (a)
                {
                    case 1:
                        Insert();
                        break;
                    case 2:
                        DisplayAll();
                        break;             
                    case 3:
                        Display();
                        break;
                    case 4:
                        Delete();
                        break;                  
                    
                    case 5:
                        Console.WriteLine("----------------------------------");
                        Console.WriteLine("Thank you!!");
                        Console.WriteLine("----------------------------------\n\n");
                        x = 1;
                        break;
                    default:
                        Console.WriteLine("----------------------------------");
                        Console.WriteLine("Enter valid value");
                        Console.WriteLine("----------------------------------");
                        break;
                }
            } while (x == 0);
            Console.ReadKey();
        }

        //public 

        public static void Insert()
        {
            Guest gg = new Guest();
            Repository rr = new Repository();
            rr.SaveData(gg);

        }
        public static void DisplayAll()
        {
            Repository rr = new Repository();
            //rr.DisplayAll();
            
            SqlDataReader dr = rr.DisplayAll();
            while(dr.Read())
            {
                Console.WriteLine("---------------------------------");

                while (dr.Read())
                {
                    Console.WriteLine("{0}--{1}--{2}--{3}", dr[0], dr[1], dr[2], dr[3]);
                }
                Console.WriteLine("---------------------------------");
            }
            
        }
        public static void Display()
        {
            Repository rr = new Repository();
            Console.WriteLine("---------------------------------");
            Console.WriteLine("Enter the Id no. of Guest");
            Console.WriteLine("---------------------------------");
            int a = Convert.ToInt32(Console.ReadLine());
            rr.Display(a);
        }
        public static void Delete()
        {
            Repository rr = new Repository();
            Console.WriteLine("---------------------------------");
            Console.WriteLine("Enter the Id no. of Guest");
            Console.WriteLine("---------------------------------");
            int id = Convert.ToInt32(Console.ReadLine());
            rr.Delete(id);
        }
        
    }
}
