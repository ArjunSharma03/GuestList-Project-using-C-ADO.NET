﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using GuestBLL;

namespace GuestDal
{
    public class Repository
    {
        public string ss = "/* add your database server name here*/";

        public void SaveData(Guest obj)
        {
            Console.WriteLine("---------------------------------");
            Console.WriteLine("Enter guest id:");
            obj.GuestId = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("Enter guest name:");
            obj.GuestName = Console.ReadLine();

            Console.WriteLine("Enter guest no:");
            obj.MobileNo = Console.ReadLine();

            Console.WriteLine("Enter guest City:");
            obj.GuestCity = Console.ReadLine();
            Console.WriteLine("---------------------------------");
            SqlConnection con = new SqlConnection(ss);

            SqlCommand cmd = new SqlCommand("Insert into Guest values(@id,@name,@no,@city)", con);
            cmd.Parameters.AddWithValue("@id", obj.GuestId);
            cmd.Parameters.AddWithValue("@name", obj.GuestName);
            cmd.Parameters.AddWithValue("@no", obj.MobileNo);
            cmd.Parameters.AddWithValue("@city", obj.GuestCity);

            con.Open();
            int check = cmd.ExecuteNonQuery();

            Console.WriteLine("---------------------------------");
            if (check > 0)
                Console.WriteLine("Data Saved");
            else
                Console.WriteLine("Error Occured");
            Console.WriteLine("---------------------------------");
            con.Close();
            //return true;
        }

        public SqlDataReader DisplayAll()
        {
            SqlConnection con = new SqlConnection(ss);

            SqlCommand cmd = new SqlCommand("Select * from Guest", con);

            con.Open();
            SqlDataReader dr = cmd.ExecuteReader();

            //con.Close();
            return dr;
        }

        public void Display(int id)
        {
            SqlConnection con = new SqlConnection(ss);

            SqlCommand cmd = new SqlCommand("Select * from Guest where GuestId="+id, con);
            con.Open();
            SqlDataReader dr = cmd.ExecuteReader();
            Console.WriteLine("---------------------------------");
            while (dr.Read())
            {
                Console.WriteLine("{0}--{1}--{2}--{3}", dr[0], dr[1], dr[2], dr[3]);
            }
            Console.WriteLine("---------------------------------");
            con.Close();
        }

        public void Delete(int id)
        {
            SqlConnection con = new SqlConnection(ss);

            SqlCommand cmd = new SqlCommand("Delete from Guest where Guestid=@id", con);
            cmd.Parameters.AddWithValue("@id", id);

            con.Open();
            int check = cmd.ExecuteNonQuery();
            Console.WriteLine("---------------------------------");
            if (check > 0)
                Console.WriteLine("Guest Deleted");
            else
                Console.WriteLine("Error Occured");
            Console.WriteLine("---------------------------------");
            con.Close();
        }
    }
}
